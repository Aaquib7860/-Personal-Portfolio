---
title: Query Engine Notebooks
navtitle: Query Engine Notebooks
layout: page
tags: [post, notebook]
---

For examples about running Query please refer to the following notebooks:

- [Global Search Notebook](/posts/query/notebooks/global_search_nb)
- [Local Search Notebook](/posts/query/notebooks/local_search_nb)

The test dataset for these notebooks can be found [here](/data/operation_dulce/dataset.zip).